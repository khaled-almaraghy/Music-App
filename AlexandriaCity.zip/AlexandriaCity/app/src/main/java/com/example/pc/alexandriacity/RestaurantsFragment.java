package com.example.pc.alexandriacity;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class RestaurantsFragment extends Fragment {

    public RestaurantsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
       View rootView = inflater.inflate(R.layout.activity_categories_list, container, false);

        //Create an array of list for restaurants
        ArrayList<Categories> restaurants = new ArrayList<Categories>();

        restaurants.add(new Categories("Koshry Al-Tahrer", getString(R.string.res_one), R.drawable.tahrer));
        restaurants.add(new Categories("Baci", getString(R.string.res_two), R.drawable.baci));
        restaurants.add(new Categories("Soltan Ayub", getString(R.string.res_three), R.drawable.soltanayob));
        restaurants.add(new Categories("El Fallah", getString(R.string.res_four), R.drawable.elfalah));
        restaurants.add(new Categories("Zanilli's", getString(R.string.res_five), R.drawable.zanils));
        restaurants.add(new Categories("Santorini", getString(R.string.res_six), R.drawable.santorini));
        restaurants.add(new Categories("Alban Swissra", getString(R.string.res_seven), R.drawable.albanswisra));
        restaurants.add(new Categories("Tejano's Mexican Grill", getString(R.string.res_eight), R.drawable.tejanos));
        restaurants.add(new Categories("Byblos", getString(R.string.res_nine), R.drawable.byblos));
        restaurants.add(new Categories("Arous El Bahr", getString(R.string.res_ten), R.drawable.aroselbahr));

        // Create an {@link ArrayAdapter}, whose data source is a list of Strings. The
        // This list item layout contains a single {@link TextView}, which the adapter will set to
        // display a single item.
        CategoriesAdapter itemsAdapter =
                new CategoriesAdapter(getActivity(), restaurants);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // activity_categories_list.xml.xml layout file.
        ListView listView = (ListView) rootView.findViewById(R.id.list);

        // Make the {@link ListView} use the {@link ArrayAdapter} we created above, so that the
        // {@link ListView} will display list items for each word in the list of restaurants.
        // Do this by calling the setAdapter method on the {@link ListView} object and pass in
        // 1 argument, which is the {@link ArrayAdapter} with the variable name itemsAdapter.
        listView.setAdapter(itemsAdapter);

       return rootView;
    }
}
