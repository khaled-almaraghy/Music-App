package com.example.pc.alexandriacity;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

/**
 * Created by pc on 12/10/2017.
 */
public class SimpleFragmentPagerAdapter extends FragmentPagerAdapter {

    private Context mContext;

    public SimpleFragmentPagerAdapter(MainActivity mainActivity, FragmentManager fm) {

        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        if (position == 0) {
            return new RestaurantsFragment();
        } else if (position == 1){
            return new MallsFragment();
        } else if (position == 2){
            return new MuseumsFragment();
        } else {
            return new CulturesFragment();
        }
    }

    @Override
    public int getCount() {
        return 4;
    }

}
