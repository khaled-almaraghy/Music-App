package com.example.pc.alexandriacity;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by pc on 12/9/2017.
 */

public class CategoriesAdapter extends ArrayAdapter<Categories> {

    private static final String LOG_TAG = CategoriesAdapter.class.getSimpleName();

    public CategoriesAdapter(@NonNull FragmentActivity context, ArrayList<Categories> resource) {
        // Here, we initialize the ArrayAdapter's internal storage for the context and the list.
        // the second argument is used when the ArrayAdapter is populating a single TextView.
        // Because this is a custom adapter for two TextViews and an ImageView, the adapter is not
        // going to use this second argument, so it can be any value. Here, we used 0.
        super(context, 0, resource);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        Categories currentCategories = getItem(position);

        View listItemView = convertView;
        if (listItemView == null){
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        // Find the TextView in the list_item.xml layout with the ID
        TextView headlineTextView = (TextView) listItemView.findViewById(R.id.header_text_view);

        // Get the headline from the current categories object and
        // set this text on the headline TextView
        headlineTextView.setText(currentCategories.getHeadline());

        // Find the TextView in the list_item.xml layout with the ID
        TextView descriptionTextView = (TextView) listItemView.findViewById(R.id.des_text_view);

        // Get the description from the current categories object and
        // set this text on the description TextView
        descriptionTextView.setText(currentCategories.getDescription());

        // Find the ImageView in the list_item.xml layout with the ID
        ImageView imageView = (ImageView) listItemView.findViewById(R.id.placeImage);

        // Get the Image from the current categories object and
        // set this Image on the view
        imageView.setImageResource(currentCategories.getImage());

        // Return the whole list item layout (containing 2 TextViews and an ImageView)
        // so that it can be shown in the ListView
        return listItemView;
    }
}
