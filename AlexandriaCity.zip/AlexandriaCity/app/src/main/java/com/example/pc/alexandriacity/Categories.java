package com.example.pc.alexandriacity;

import android.content.Intent;

/**
 * Created by pc on 12/9/2017.
 * {@link Categories} represents a list of places that user wants to check out in Alexandria city.
 * It contains a place name and description for that places.
 */

public class Categories {

    /** Headline of each place within view*/
    private String mHeadline;

    /** Description of each place within view*/
    private int mTranslation;

    private int mImageResource;

    public Categories(String headline, int description, int imageResouce){
        mHeadline = headline;
        mTranslation = description;
        mImageResource = imageResouce;
    }

    // Get the Headline of place.
    public String getHeadline(){
        return mHeadline;
    }

    // Get the Description of place.
    public int getDescription(){
        return mTranslation;
    }

    // Get the Description of place.
    public int getImage(){ return mImageResource; }
}
